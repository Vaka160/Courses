/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/luboe/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/luboe/test/integration/pages/Worklist",
	"zjblessons/luboe/test/integration/pages/Object",
	"zjblessons/luboe/test/integration/pages/NotFound",
	"zjblessons/luboe/test/integration/pages/Browser",
	"zjblessons/luboe/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.luboe.view."
	});

	sap.ui.require([
		"zjblessons/luboe/test/integration/WorklistJourney",
		"zjblessons/luboe/test/integration/ObjectJourney",
		"zjblessons/luboe/test/integration/NavigationJourney",
		"zjblessons/luboe/test/integration/NotFoundJourney",
		"zjblessons/luboe/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});