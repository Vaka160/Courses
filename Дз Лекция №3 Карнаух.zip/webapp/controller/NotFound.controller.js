sap.ui.define([
		"zjblessons/luboe/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("zjblessons.luboe.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);